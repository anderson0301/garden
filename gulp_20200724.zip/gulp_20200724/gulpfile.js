(() => {
    'use strict';

    /*
     * ----------------------------------------------------------------------------------
     * Package
     * ----------------------------------------------------------------------------------
     */
    const gulp = require('gulp');
    const sass = require('gulp-sass');
    const csscomb = require('gulp-csscomb');
    const autoprefixer = require('gulp-autoprefixer');
    const plumber = require('gulp-plumber');
    const postcss = require('gulp-postcss');
    const mqpacker = require('css-mqpacker');
    const lineEndingCorrector = require('gulp-line-ending-corrector');
    const header = require('gulp-header');
    const replace = require('gulp-replace');
    const browser = require('browser-sync').create();
    const connectSSI = require('connect-ssi');
    const path = require('path');

    /*
     * ----------------------------------------------------------------------------------
     * Config
     * ----------------------------------------------------------------------------------
     */

    // gulpfile.jsからの相対パス指定で各ディレクトリまでのパスを設定。(案件ごとに設定)
    const PATHS = {
        projectRoot: 'docs/',
        img: 'docs/share/images',
        js: 'docs/share/js',
        sassCommon: '_dev/scss/siteCommon',// サイト全体のSCSSスタイル
        sassUnique: '_dev/scss/siteUnique',// ページ固有のSCSSスタイル
        css: 'docs/share/css'
    };

    /*
     * ----------------------------------------------------------------------------------
     * Sass（サイト全体の共通スタイル）
     * ----------------------------------------------------------------------------------
     */
    gulp.task('CSS_COMMON_BUILD', () => gulp.src(`${PATHS.sassCommon}/**/*.scss`).
        pipe(plumber({
            errorHandler: (err) => {
                // eslint-disable-next-line no-console
                console.log(err.messageFormatted);
                this.emit('end');
            }
        })).
        pipe(sass({
            outputStyle: 'expanded'
        })).
        pipe(autoprefixer()).
        pipe(csscomb()).
        pipe(postcss([
            mqpacker({
                sort: true
            })
        ])).
        pipe(lineEndingCorrector({
            eolc: 'CRLF',
            encoding: 'utf8'
        })).
        pipe(replace(/@charset "UTF-8";/g, '')).
        pipe(header('@charset "UTF-8";\n\n')).
        pipe(gulp.dest(PATHS.css)));

    /*
     * ----------------------------------------------------------------------------------
     * Sass（ページ固有のスタイル）
     * ----------------------------------------------------------------------------------
     */
    gulp.task('CSS_UNIQUE_BUILD', () => gulp.src(`${PATHS.sassUnique}/**/*.scss`).
        pipe(plumber({
            errorHandler: (err) => {
                // eslint-disable-next-line no-console
                console.log(err.messageFormatted);
                this.emit('end');
            }
        })).
        pipe(sass({
            outputStyle: 'expanded'
        })).
        pipe(autoprefixer()).
        pipe(csscomb()).
        pipe(postcss([
            mqpacker({
                sort: true
            })
        ])).
        pipe(lineEndingCorrector({
            eolc: 'CRLF',
            encoding: 'utf8'
        })).
        pipe(replace(/@charset "UTF-8";/g, '')).
        pipe(header('@charset "UTF-8";\n\n')).
        pipe(gulp.dest(PATHS.projectRoot)));

    /*
     * ----------------------------------------------------------------------------------
     * Default（共通スタイルのコンパイル監視）
     * ----------------------------------------------------------------------------------
     */
    gulp.task('default', gulp.series(gulp.parallel('CSS_COMMON_BUILD'), () => {
        gulp.watch(`${PATHS.sassCommon}/**/*.scss`, gulp.series('CSS_COMMON_BUILD'));
    }));

    /*
     * ----------------------------------------------------------------------------------
     * watchUniqueStyles（ページ固有スタイルのコンパイル監視）
     * ----------------------------------------------------------------------------------
     */
    gulp.task('watchUniqueStyles', gulp.series(gulp.parallel('CSS_UNIQUE_BUILD'), () => {
        gulp.watch(`${PATHS.sassUnique}/**/*.scss`, gulp.series('CSS_UNIQUE_BUILD'));
    }));

    /*
     * ----------------------------------------------------------------------------------
     * Live Reload
     * ----------------------------------------------------------------------------------
     */

    const browserReload = () => {
        browser.reload({
            stream: true
        });
    };

    browser.init({
        files: [
            'docs/**/*.css',
            'docs/**/*.js',
            'docs/**/*.html'
        ],

        server: {
            baseDir: 'docs/',
            middleware: [
              connectSSI({
                baseDir: __dirname + '/docs',
                ext: '.html'
              })
            ]
          }
    });

    browserReload();
})();
