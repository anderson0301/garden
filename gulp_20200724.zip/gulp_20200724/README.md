# パートナー部構築案件初期テンプレート
## 概要
各種リンターの設定ファイル、gulpのsassコンパイル等をまとめたテンプレート一式です。  

### 基本的な設定済みの物（※ 使用時は案件の応じて要カスタマイズ）
1. gulp開発環境
    - sassコンパイル
    - ライブリロード
1. `.gitignore`
1. `.gitattributes`
1. `eslint`
1. `sass-lint`
1. `vlint`
1. プレコミットフック
    - `vlint`
    - `eslint`
    - `sass-lint`

## 構成ファイル
|  フォルダ  |  ファイル  |  内容  |
| ---- | ---- | ---- |
|  docs/  |  -  |  実際にサイトで使用するリソース  |
|  _dev/  |  -  |  SCSSや画像圧縮などの設定が格納された開発ディレクトリ  |
|  _dev/scss/siteCommon/  |  -  |  サイト共通のSCSSファイルを格納するディレクトリ  |
|  _dev/scss/siteUnique/  |  -  |  ページ固有のSCSSファイルを格納するディレクトリ  |
|  package.json  |  -  |  プロジェクトルートで定義される、各種リンター・scssコンパイルなどのプラグインが列挙されたファイル  |
|  gulpfile.js  |  -  |  gulpを実行する際の設定（※ 案件ごとに調整する）  |
|  .browserslistrc  |  -  |  Autoprefixerで指定するブラウザの設定ファイル  |
|  _install.bat  |  -  |  node_modules/をインストールするバッチファイル  |
|  _watchCommon.bat  |  -  |  サイト共通SCSSファイルのコンパイルを実行/監視するバッチファイル  |
|  _watchUnique.bat  |  -  |  ページ固有SCSSファイルのコンパイルを実行/監視するバッチファイル  |
|  _lint-js.bat  |  -  |  eslintを実行するバッチファイル  |
|  _lint-sass.bat  |  -  |  sasslintを実行するバッチファイル  |
|  _lint-vlint-html.bat  |  -  |  vlint（html）を実行するバッチファイル  |
|  _lint-vlint-css.bat  |  -  |  vlint（css）を実行するバッチファイル  |
|  .huskyrc.json  |  -  |  プレコミットフック設定ファイル  |
|  .lintstagedrc.yaml  |  -  |  プレコミットフック設定ファイル  |
|  .eslintignore  |  -  |  JSのリンターから除外したいディレクトリなどを指定するのに使用（※不要の場合削除）  |
|  .eslintrc  |  -  |  JSのリンター設定ファイル  |
|  .sass-lint.yml  |  -  |  SCSSのリンター設定ファイル  |
|  .vlintrc.yaml  |  -  |  vlint設定ファイル  |
|  .gitignore  |  -  |  Gitの除外設定ファイル  |
|  .gitattributes  |  -  |  Git LFSの設定ファイル  |

## npmパッケージのインストール方法
node.jsインストール後「_install.bat」を実行する ※

※node.jsがインストールされていない場合は[ここから推奨版を](https://nodejs.org/ja/)ダウンロード

## ブラウザ指定用設定ファイルについて
`.browserslistrc`は`Autoprefixer`で使用する設定ファイルです。  
案件ごとに定義されているブラウザに応じて編集・更新を行います。

- [詳しい指定方法](https://github.com/browserslist/browserslist#full-list)

## 備考

### `npm ~`コマンドがわからない方向け
- [いまさら聞けない！npmのこれだけは知っておきたい基礎知識](https://www.webprofessional.jp/beginners-guide-node-package-manager/)

### モジュール一覧を作成する場合
以下のページから、モジュール一覧のセットがダウンロードできます。(※社内用)

- [mml.js - MLC Module List](https://ssh.site.mitsue.com/ssh/dev/9/)

### ES5の案件について（JSリンター）
当テンプレートのJSリンター設定ファイルは、ES5ベースではないためその場合は以下のコマンドを実行する。

1. `npm uninstall @mitsue/eslint-config` を実行
1. `npm i --save-dev @mitsue/eslint-config-es5` を実行
1. `.eslintrc`内の記述を変更 ※

※ `.eslintrc`の記述を以下へ変更する。

```json
{
  "extends": "@mitsue/eslint-config-es5"
}
```

### リンターの詳しい設定項目について
#### ES Lint
- [公式 ルール一覧](https://eslint.org/docs/rules/)
- [日本語訳 : ESLint ルール 一覧 (日本語)](https://garafu.blogspot.com/2017/02/eslint-rules-jp.html)

#### SASS Lint
- [公式 ルール一覧](https://github.com/sasstools/sass-lint/tree/master/docs/rules)
- [日本語訳 : sass-lintのエラールールを日本語で分かるようにした](https://qiita.com/nezurika/items/4cc858ee9ebd6154dd44)

---

## 更新履歴
### 2019/11/20
- 初期リリース
### 2020/06/03
- 最新版にアップデート
### 2020/06/24
- ページ固有cssもビルド可能にアップデート