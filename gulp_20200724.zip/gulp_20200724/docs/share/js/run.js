(function () {
    'use strict';
}());
